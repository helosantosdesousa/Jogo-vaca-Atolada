//carro 1
let xCar1 =600
let veloCar1 = 2.5

//carro 2
let xCar2 = 600
let veloCar2 = 3

//carro 3
let xCar3 = 600
let veloCar3 = 2

function mostraCarro (){
    image (car1, xCar1,40, 50, 40);
  image (car2, xCar2, 95, 50, 40);
  image (car3, xCar3, 150, 50,40);
}


function moviCarro (){
  
  xCar1-=veloCar1;
  xCar2 -= veloCar2;
  xCar3 -= veloCar3;
}

function voltaCarro () {
if (xCar1 < -30) {
  xCar1= 550
}
  
if (xCar2< -30) {
  xCar2= 550
}
    
    
if (xCar3<-30) {
  xCar3= 550
}
}