
function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(estrada);
  mostraAtor ();
  mostraCarro ();
  moviCarro ();
  moviAtor();
  voltaCarro ();
  voltaAtor();
}

function mostraCarro (){
  image (car1, xCar1,40, 50,40);
  image (car2, xCar2, 95, 50, 40);
  image (car3, xCar3, 150, 50,40);
}


function moviCarro (){
  
  xCar1= xCar1 -2;
  xCar2 = xCar2 -2;
  xCar3 = xCar3-2;
}



