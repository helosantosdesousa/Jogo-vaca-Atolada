//cod ator

let yAtor = 366

function mostraAtor(){
   image (Ator,100, yAtor, 30, 30);
}

function moviAtor () {
  if (keyIsDown(UP_ARROW)) {
    yAtor=yAtor-3;}
  if (keyIsDown(DOWN_ARROW)) {
    yAtor=yAtor+3;}
}

//ta errado
function voltaAtor (){
if (yAtor <-0){
    yAtor = 366;
}
}
