let estrada;
let Ator;
let car1;


function preload (){
  estrada = loadImage("imagens/estrada.png");
  Ator =loadImage("imagens/ator-1.png");
  car1 = loadImage ("imagens/carro-1.png");
  car2 = loadImage ("imagens/carro-2.png");
  car3 = loadImage ("imagens/carro-3.png")
}